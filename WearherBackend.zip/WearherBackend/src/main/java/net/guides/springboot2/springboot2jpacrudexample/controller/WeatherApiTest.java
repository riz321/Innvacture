package net.guides.springboot2.springboot2jpacrudexample.controller;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;

public class WeatherApiTest {
    @Test
    public void multiplicationOfZeroIntegersShouldReturnZero() {
    	WeatherApi weatherApi =new WeatherApi(); 
    	//assertNull(weatherApi.getWeatherData("10001"));
        assertNotNull(weatherApi.getWeatherData("10001"));
    }

}
