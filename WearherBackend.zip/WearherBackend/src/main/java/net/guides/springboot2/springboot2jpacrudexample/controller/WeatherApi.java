package net.guides.springboot2.springboot2jpacrudexample.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
public class WeatherApi {
	@Value("${external.server.url}")
	String url;
	
	public ResponseEntity<Object>  getWeatherData(String zip){
		RestTemplate  restTemplate =new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<String> entity = new HttpEntity<String>(headers);
		Object data= restTemplate.exchange(url+"?zip="+zip+"&appid=c28342a72bef5e1e63993579cf8de579", HttpMethod.GET,entity, Object.class).getBody();
		return ResponseEntity.ok(data);
	}
}
