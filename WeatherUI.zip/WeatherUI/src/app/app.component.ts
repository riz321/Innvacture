import { Component } from '@angular/core';
import { HttpService } from './http.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Weather Information Acording to Zip Code.';
  dataOfWeather:any;

  constructor(private httpService:HttpService){

  }
   zip:number=0;
  ngOnInit() {
  }

  reloadData() {
    var isValidZip = /(^\d{5}$)|(^\d{5}-\d{4}$)/.test(this.zip.toString());
    if(!isValidZip){
       alert("Zip code is not valid....!");
       return false;
    }
     this.httpService.getWeatherData(this.zip).subscribe(
      data => {
        this.dataOfWeather=data;
        console.log(data);
      },
      error => alert("Netwok Issue..!"));
      this.dataOfWeather=[];
  }
}
